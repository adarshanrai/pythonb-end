from fpdf import FPDF
import os
from tkinter import Tk, filedialog, messagebox
import tkinter as tk
from PIL import Image
import glob


# Simple Image to PDF Converter using fpdf2

class ImageToPDF:
    def __init__(self, root):
        self.root = root
        self.root.title("Image to PDF Converter")
        self.root.geometry("600x500")
        
        # Variables
        self.image_paths = []
        self.title = tk.StringVar(value="My Images")
        
        self.setup_ui()
        
    def setup_ui(self):
        # Title Frame
        title_frame = tk.Frame(self.root, padx=20, pady=15)
        title_frame.pack(fill="x")
        
        tk.Label(title_frame, text="PDF Title:", font=("Arial", 12, "bold")).pack(side="left")
        title_entry = tk.Entry(title_frame, textvariable=self.title, width=40, font=("Arial", 11))
        title_entry.pack(side="left", padx=10)
        
        images_frame = tk.Frame(self.root, padx=20, pady=10)
        images_frame.pack(fill="both", expand=True)
        
        tk.Label(images_frame, text="Images:", font=("Arial", 12, "bold")).pack(anchor="w")
        
     
        list_frame = tk.Frame(images_frame)
        list_frame.pack(fill="both", expand=True, pady=10)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.images_listbox = tk.Listbox(list_frame, height=10, width=70, 
                                         yscrollcommand=scrollbar.set,
                                         font=("Arial", 10))
        self.images_listbox.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.images_listbox.yview)
        
        
        button_frame = tk.Frame(images_frame)
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Add Images", command=self.add_images,
                 bg="#4CAF50", fg="white", font=("Arial", 10, "bold"),
                 padx=20, pady=8).pack(side="left", padx=5)
        
        tk.Button(button_frame, text="Remove Selected", command=self.remove_image,
                 bg="#f44336", fg="white", font=("Arial", 10, "bold"),
                 padx=20, pady=8).pack(side="left", padx=5)
        
        tk.Button(button_frame, text="Clear All", command=self.clear_all,
                 bg="#FF9800", fg="white", font=("Arial", 10, "bold"),
                 padx=20, pady=8).pack(side="left", padx=5)
        
      
        options_frame = tk.Frame(images_frame)
        options_frame.pack(pady=10)
        
        self.fit_to_page = tk.BooleanVar(value=True)
        tk.Checkbutton(options_frame, text="Fit images to page", 
                      variable=self.fit_to_page).pack(side="left")
        
      
        self.info_label = tk.Label(images_frame, text="", font=("Arial", 9), fg="blue")
        self.info_label.pack(pady=5)
        
        
        tk.Button(self.root, text="Create PDF", command=self.create_pdf,
                 bg="#2196F3", fg="white", font=("Arial", 14, "bold"),
                 padx=40, pady=12).pack(pady=20)
        
      
        self.status_label = tk.Label(self.root, text="", font=("Arial", 10))
        self.status_label.pack()
        
    def add_images(self):
        """Open file dialog to select multiple images"""
        file_paths = filedialog.askopenfilenames(
            title="Select Images",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.bmp *.tiff"),
                ("All files", "*.*")
            ]
        )
        
        added_count = 0
        for file_path in file_paths:
            if file_path not in self.image_paths:
                self.image_paths.append(file_path)
                self.images_listbox.insert(tk.END, os.path.basename(file_path))
                added_count += 1
        
        if added_count > 0:
            self.info_label.config(text=f"Total images: {len(self.image_paths)}", fg="green")
            self.status_label.config(text=f"✅ Added {added_count} image(s)", fg="green")
        else:
            self.status_label.config(text="No new images added", fg="orange")
        
    def remove_image(self):
        """Remove selected image from list"""
        selection = self.images_listbox.curselection()
        if selection:
            index = selection[0]
            filename = self.images_listbox.get(index)
            self.images_listbox.delete(index)
            del self.image_paths[index]
            self.info_label.config(text=f"Total images: {len(self.image_paths)}")
            self.status_label.config(text=f"❌ Removed: {filename}", fg="orange")
    
    def clear_all(self):
        """Clear all images"""
        if self.image_paths:
            self.image_paths.clear()
            self.images_listbox.delete(0, tk.END)
            self.info_label.config(text="Total images: 0")
            self.status_label.config(text="🗑️ All images cleared", fg="orange")
    
    def get_image_dimensions(self, image_path):
        """Get image dimensions using PIL"""
        try:
            with Image.open(image_path) as img:
                return img.size
        except:
            return (0, 0)
    
    def create_pdf(self):
        """Generate PDF with images using fpdf2"""
        if not self.image_paths:
            messagebox.showerror("Error", "Please add at least one image")
            return
        
        title = self.title.get().strip()
        if not title:
            title = "My Images"
        
      
        filename = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            initialfile=f"{title.replace(' ', '_')}.pdf"
        )
        
        if not filename:
            return
        
        try:
            # Create PDF
            pdf = FPDF(orientation='L', unit='mm', format='A4')
            pdf.set_auto_page_break(auto=False)
            
          
            pdf.add_page()
            
            pdf.set_font("Helvetica", "B", 24)
            pdf.cell(0, 40, title, ln=True, align='C')
            
       
            for idx, img_path in enumerate(self.image_paths, 1):
                if os.path.exists(img_path):
                    
                    pdf.add_page()
                    
                    # Get image dimensions
                    img_width, img_height = self.get_image_dimensions(img_path)
                    
                    if self.fit_to_page.get():
                    
                        page_width = 277  # A4 landscape in mm (297mm - margins)
                        page_height = 190  # A4 landscape in mm (210mm - margins)
                        
                       
                        width_scale = page_width / img_width
                        height_scale = page_height / img_height
                        scale = min(width_scale, height_scale)
                        
                    
                        scaled_width = img_width * scale
                        scaled_height = img_height * scale
                        x = (297 - scaled_width) / 2  # Center horizontally on A4 landscape
                        y = (210 - scaled_height) / 2  # Center vertically on A4 landscape
                        
                        
                        pdf.image(img_path, x=x, y=y, w=scaled_width, h=scaled_height)
                    else:
                       pdf.image(img_path, x=10, y=10, w=img_width * 0.264583, h=img_height * 0.264583)
            
            # Save PDF
            pdf.output(filename)
            
            self.status_label.config(text=f"✅ PDF created successfully: {filename}", fg="green")
            messagebox.showinfo("Success", f"PDF created successfully!\n\nSaved as: {filename}\n\nTotal images: {len(self.image_paths)}")
            
        except Exception as e:
            self.status_label.config(text=f"❌ Error: {str(e)}", fg="red")
            messagebox.showerror("Error", f"Failed to create PDF:\n{str(e)}")

# No GUI, Just Drag and Drop

def simple_image_to_pdf():
    """Ultra simple version - select images and create PDF"""
    from tkinter import Tk, filedialog, simpledialog
    
    root = Tk()
    root.withdraw()
    
    # Get PDF title
    title = simpledialog.askstring("PDF Title", "Enter PDF title:", initialvalue="My Images")
    if not title:
        title = "My Images"
    
    # Select images
    print("\n📷 Select images to convert to PDF...")
    image_paths = filedialog.askopenfilenames(
        title="Select Images",
        filetypes=[("Image files", "*.jpg *.jpeg *.png *.gif *.bmp *.tiff")]
    )
    
    if not image_paths:
        print("❌ No images selected!")
        return
    
    
    filename = filedialog.asksaveasfilename(
        defaultextension=".pdf",
        filetypes=[("PDF files", "*.pdf")],
        initialfile=f"{title.replace(' ', '_')}.pdf"
    )
    
    if not filename:
        print("❌ No save location selected!")
        return
    
    try:
        
        pdf = FPDF(orientation='L', unit='mm', format='A4')
        pdf.set_auto_page_break(auto=False)
        
        
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 24)
        pdf.cell(0, 40, title, ln=True, align='C')
        
     
        for img_path in image_paths:
            pdf.add_page()
            pdf.image(img_path, x=10, y=10, w=277, h=190)  # Fit to page with margins
        
        pdf.output(filename)
        print(f"✅ PDF created successfully: {filename}")
        print(f"📄 Total images: {len(image_paths)}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
    
    root.destroy()


if __name__ == "__main__":
    print("Select mode:")
    print("1. GUI Mode (with preview)")
    print("2. Simple Mode (quick convert)")
    
    choice = input("Enter your choice (1 or 2): ").strip()
    
    if choice == "1":
        root = tk.Tk()
        app = ImageToPDF(root)
        root.mainloop()
    else:
        simple_image_to_pdf()